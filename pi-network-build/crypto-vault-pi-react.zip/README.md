# Crypto Vault - Pi Network Edition

A secure, local cryptocurrency wallet manager designed for Pi Network.

## Features
- OTP email login (EmailJS)
- PIN-protected vault
- Store multiple crypto wallets (Bitcoin, Ethereum, Pi, etc.)
- Auto-lock after 5 minutes of inactivity
- Export wallet backups
- All data stored locally in browser

## Installation
Upload this zip file to Pi App Studio

## Version
1.0.0
